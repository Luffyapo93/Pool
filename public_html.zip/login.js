document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const errorMessage = document.getElementById('error-message');

    loginForm.addEventListener('submit', (event) => {
        // Evitamos que el formulario se envíe de la forma tradicional
        event.preventDefault();

        // Obtenemos los valores de los campos
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // --- Credenciales de prueba ---
        const correctUser = 'admin';
        const correctPass = '1234';

        if (username === correctUser && password === correctPass) {
            // Redirigimos a la página principal
            window.location.href = 'principal.html';
        } else {
            // Si son incorrectas, mostramos un mensaje de error
            errorMessage.textContent = 'Usuario o contraseña incorrectos.';
        }
    });
});