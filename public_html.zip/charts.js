document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('causesChart');

    if (ctx) {
        new Chart(ctx, {
            type: 'pie', // Tipo de gráfico: 'pie' (pastel), también puede ser 'bar' (barras).
            data: {
                labels: [
                    'Imprudencia del Conductor',
                    'Exceso de Velocidad',
                    'Imprudencia del Peatón',
                    'Fallas Mecánicas',
                    'Otras Causas'
                ],
                datasets: [{
                    label: '% de Siniestros',
                    data: [45, 25, 12, 8, 10], // Datos de ejemplo, deben sumar 100
                    backgroundColor: [
                        '#c0392b', // Rojo (color principal de tu web)
                        '#e74c3c', // Rojo más claro
                        '#f39c12', // Naranja
                        '#34495e', // Gris oscuro
                        '#95a5a6'  // Gris claro
                    ],
                    borderColor: '#ffffff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top', // Muestra las etiquetas arriba del gráfico
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed !== null) {
                                    // Añade el símbolo de porcentaje '%' al tooltip
                                    label += context.parsed + '%';
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    }
});