# Interim data

Este directorio contiene datos intermedios que han sido transformados o combinados de alguna manera. Estos datos intermedios se utilizan como entrada para el análisis final, que se encuentra en el directorio `data/processed`.